from django.db import models

# Create your models here.
class Customer(models.Model):
    cusid=models.IntegerField()
    name=models.CharField(max_length=100)
    book=models.CharField(max_length=100)
    date=models.DateField()

