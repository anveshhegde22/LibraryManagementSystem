from django.urls import path
from .api import CustomerCreateApi,CustomerApi,CustomerUpdateApi,CustomerDeleteApi

urlpatterns=[
    path('api/',CustomerApi.as_view()),
    path('api/create/',CustomerCreateApi.as_view()),
    path('api/<int:pk>',CustomerUpdateApi.as_view()),
    path('api/<int:pk>/delete',CustomerDeleteApi.as_view()),
]